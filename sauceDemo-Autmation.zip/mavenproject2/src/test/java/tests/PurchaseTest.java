package tests;


import org.testng.Assert;
import org.testng.annotations.Test;

import base.BaseTest;
import pages.LoginPage;
import pages.ProductPage;

public class PurchaseTest extends BaseTest {

    @Test
    public void addToCartTest() {

        // Login
        LoginPage login = new LoginPage(driver);
        login.login("standard_user", "secret_sauce");

        // Products page
        ProductPage products = new ProductPage();

        // Add product
        products.addItemToCart();

        // Open cart
        products.openCart();

        // Verify cart page
        Assert.assertTrue(
            driver.getCurrentUrl().contains("cart"),
            "Cart page not opened"
            
      
            
            
            
            
            
        );
    }
}
