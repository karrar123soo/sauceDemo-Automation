package tests;


		
		//AUTOMATIC DATA (config se)
		

		import org.openqa.selenium.By;
		import org.openqa.selenium.support.ui.ExpectedConditions;
		import org.openqa.selenium.support.ui.WebDriverWait;
		import org.testng.Assert;
		import org.testng.annotations.Test;

import base.BaseTest;

import java.time.Duration;

		public class LoginTest extends BaseTest {

		    @Test
		    public void loginTest() {

		        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

		        // Username
		        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("user-name")))
		                .sendKeys("standard_user");

		        // Password
		        driver.findElement(By.id("password"))
		                .sendKeys("secret_sauce");

		        // Login button
		        driver.findElement(By.id("login-button")).click();

		        // Validate successful login
		        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("inventory_container")));

		        Assert.assertTrue(
		                driver.getCurrentUrl().contains("inventory"),
		                "Login failed"
		        );
		    }
		}