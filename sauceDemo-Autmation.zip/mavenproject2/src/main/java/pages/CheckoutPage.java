package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPage {
	WebDriver driver;
	
	public CheckoutPage(WebDriver driver) {
		this.driver=driver;
		
	}
	By firstName= By.id("first-name");
	By lastName= By.id("last-name");
	By postal = By.id("postal-code");
	By continueBtn= By.id("continue");
	By finishBtn= By.id("finish");
	
	public void clickContinue () {
		driver.findElement(continueBtn).click();
	}
	public void clickFinish() {
		driver.findElement(finishBtn);
	}
			
	

}
