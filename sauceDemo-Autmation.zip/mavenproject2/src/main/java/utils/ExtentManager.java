package utils;

import com.aventstack.extentreports.ExtentReports;




	import com.aventstack.extentreports.ExtentReports;
	import com.aventstack.extentreports.reporter.ExtentSparkReporter;

	public class ExtentManager {

	    private static ExtentReports extent;

	    public static ExtentReports getExtentReport() {

	        if (extent == null) {

	            ExtentSparkReporter spark =
	                    new ExtentSparkReporter("test-output/ExtentReport.html");

	            spark.config().setReportName("Automation Test Report");
	            spark.config().setDocumentTitle("Extent Report");

	            extent = new ExtentReports();
	            extent.attachReporter(spark);
	            extent.setSystemInfo("Tester", "karrar");
	            extent.setSystemInfo("Browser",  "Chrome");
	        }

	        return extent;
	    }
	
	
	}


