package base;




import com.aventstack.extentreports.ExtentReports;

	import java.io.File;
	import java.io.IOException;
	import java.lang.reflect.Method;
	import java.nio.file.Files;

	import org.openqa.selenium.OutputType;
	import org.openqa.selenium.TakesScreenshot;
	import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.AfterSuite;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.BeforeSuite;

	import com.aventstack.extentreports.ExtentReports;
	import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ExtentManager;


	public class BaseTest {

	    
		protected WebDriver driver;
	    protected static ExtentReports extent;
	    protected ExtentTest test;
	  

	    // ---------- EXTENT START ----------
	    @BeforeSuite
	    public void startReport() {
	    	new File("reports").mkdirs();

	    	ExtentSparkReporter spark =
	    	        new ExtentSparkReporter("reports/karrar111.html");

	    	extent = new ExtentReports();
	    	extent.attachReporter(spark);
	 
	    }

	    // ---------- BROWSER START ----------
	    @BeforeMethod
	    public void setup(Method method) {

	        test = extent.createTest(method.getName());
	       // WebDriverManager.chromedriver().setup();
	        driver=new ChromeDriver();
	        driver.manage().window().maximize();
	        driver.get("https://www.saucedemo.com/");

	        
	    }

	    private Object chromedriver() {
			// TODO Auto-generated method stub
			return null;
		}

		// ---------- SCREENSHOT + CLOSE ----------
	    @AfterMethod
	    public void tearDown(ITestResult result) throws IOException {

	        if (result.getStatus() == ITestResult.FAILURE) {

	            test.fail(result.getThrowable());

	            TakesScreenshot ts = (TakesScreenshot) driver;
	            File src = ts.getScreenshotAs(OutputType.FILE);

	            File dest = new File(
	                "src/test/resources/screenshots/" 
	                + result.getName() + ".png"
	            );

	            dest.getParentFile().mkdirs();
	            Files.copy(src.toPath(), dest.toPath());

	            test.addScreenCaptureFromPath(dest.getAbsolutePath());
	        }

	        else if (result.getStatus() == ITestResult.SUCCESS) {
	            test.pass("Test Passed");
	        }

	        else if (result.getStatus() == ITestResult.SKIP) {
	            test.skip("Test Skipped");
	        }

	        if (driver != null) {
	            driver.quit();
	        }
	    }
	    
	           
	            
	        
	    

	    // ---------- EXTENT END ----------
	    
	    

	@AfterSuite
	public void endReport() {

	    System.out.println(">>> AFTER SUITE CALLED <<<");

	    if (extent != null) {
	        extent.flush();
	        System.out.println(">>> EXTENT FLUSH DONE <<<");
	    } else {
	        System.out.println(">>> EXTENT IS NULL <<<");
	    }
	}
	}
	
	
	    
	

	
	
	
	
	

