# Selenium TestNG Extent Reports Framework

This project is a basic Selenium automation framework using:
- Java
- Selenium WebDriver
- TestNG
- Extent Reports
- Maven

## 📁 Project Structure